
	  [Projekt zaliczeniowy: "Gra Wisielec"] 

____________________________________________________________________________________________________________________________________________________________________

	Omówienie zmian między werjsami:

	v4.2.0  - optymalizacja rankingu, dodanie "Panelu administratora".
	v4.0 	- pobieranie punktacji graczy z bazy, ukończenie Menu Głównego w całości, modyfikacja okna "Mój profil", uporządkowanie plików graficznych.
	v3.1 	- stworzenie okien "Ranking" oraz "Mój profil".
	v2.0 	- rozbudowanie Menu głównego o tryby gry (Solo/Duet) "Normalny" i "Wyścig z czasem".
	v1.0 	- utworzenie poprawnie działającego okna logowania (połączenie i weryfikacja współpracująca z bazą danych), początkowy zarys Menu głównego.

____________________________________________________________________________________________________________________________________________________________________

	Twórcy:

	- Dawid Odolczyk
	- Paweł Osiński	
	- Konrad Żyra

____________________________________________________________________________________________________________________________________________________________________